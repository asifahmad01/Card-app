package com.example.phoneauthdemo
//
//import android.os.Bundle
//import androidx.appcompat.app.AppCompatActivity
//import android.widget.Button
//import android.widget.EditText

    // verification phone number

//    import android.os.Bundle
//    import android.util.Log
//    import androidx.appcompat.app.AppCompatActivity
//    import com.google.firebase.auth.FirebaseAuth
//    import com.google.firebase.auth.PhoneAuthOptions
//    import com.google.firebase.auth.PhoneAuthProvider
//    import java.util.concurrent.TimeUnit
//
//    class ManageOTP : AppCompatActivity() {
//        private lateinit var phoneNumber: String // Assume this is initialized correctly
//
//        override fun onCreate(savedInstanceState: Bundle?) {
//            super.onCreate(savedInstanceState)
//            setContentView(R.layout.activity_manageotp)
//
//            // Get the phone number passed from the previous activity
//            phoneNumber = intent.getStringExtra("mobile") ?: ""
//
//            // Call the function to initiate OTP verification
//            initiateOtp()
//        }
//
//        private fun initiateOtp() {
//            // Initialize Firebase Auth
//            val auth = FirebaseAuth.getInstance()
//
//            // Callback for phone authentication
//            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
//                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
//                    // This callback will be invoked in two situations:
//                    // 1 - Instant verification. In some cases, the phone number can be instantly verified without needing to send or enter an OTP.
//                    // 2 - Auto-retrieval. On some devices, Google Play services can automatically detect the incoming verification SMS and perform verification without user action.
//                    Log.d(TAG, "onVerificationCompleted:$credential")
//
//                    // TODO: Handle verification completion (e.g., sign in the user)
//                }
//
//                override fun onVerificationFailed(e: FirebaseException) {
//                    // This callback is invoked for invalid requests (e.g., invalid phone number, network issues)
//                    Log.w(TAG, "onVerificationFailed", e)
//
//                    // TODO: Handle verification failure (e.g., show error message to the user)
//                }
//
//                override fun onCodeSent(
//                    verificationId: String,
//                    token: PhoneAuthProvider.ForceResendingToken
//                ) {
//                    // The SMS verification code has been sent to the provided phone number
//                    Log.d(TAG, "onCodeSent:$verificationId")
//
//                    // TODO: Save the verification ID and resending token for later use (if needed)
//                }
//            }
//
//            // Build phone auth options and start verification
//            val options = PhoneAuthOptions.newBuilder(auth)
//                .setPhoneNumber(phoneNumber) // Phone number to verify
//                .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
//                .setActivity(this) // Activity (for callback binding)
//                .setCallbacks(callbacks) // Callbacks
//                .build()
//
//            PhoneAuthProvider.verifyPhoneNumber(options)
//        }
//
//        companion object {
//            private const val TAG = "ManageOTP"
//        }
//  }
//
//}
