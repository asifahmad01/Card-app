package com.example.cardapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.cardapp.databinding.ActivityMainBinding
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener



//import android.content.Intent
//import android.os.Bundle
//import android.view.View
//import android.widget.Button
//import android.widget.EditText
//import androidx.appcompat.app.AppCompatActivity
//import com.hbb20.CountryCodePicker
//
//



class MainActivity : AppCompatActivity() {
    private var firebaseDatabase: FirebaseDatabase? = null
    private var databaseReference: DatabaseReference? = null
    private val noteList = mutableListOf<Note>()

//    OTP

//    private lateinit var ccp: CountryCodePicker
//    private lateinit var ph: String: EditText
//    private lateinit var button: Button1: Button
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//
//        t1 = findViewById(R.id.phoneNumber)
//        ccp = findViewById(R.id.ccp)
//        ccp.registerCarrierNumberEditText(t1)
//        b1 = findViewById(R.id.button1)
//
//        b1.setOnClickListener {
//            val intent = Intent(this@MainActivity, ManageOTP::class.java)
//            intent.putExtra("mobile", ccp.fullNumberWithPlus.replace(" ", ""))
//            startActivity(intent)
//        }
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firebaseDatabase = FirebaseDatabase.getInstance()
        databaseReference = firebaseDatabase?.getReference("data")

        val btnSecondActivity = findViewById<Button>(R.id.button1)
        btnSecondActivity.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)

            // Fetch data from UI
            val phoneNumberEditText = findViewById<EditText>(R.id.phoneNumber)
            val gsnNumberEditText = findViewById<EditText>(R.id.gsnNumber4)
            val dobEditText = findViewById<EditText>(R.id.dateText)

            val ph = phoneNumberEditText.text.toString()
            val gsn = gsnNumberEditText.text.toString()
            val dob = dobEditText.text.toString()

            // Save data to Firebase
            saveData(ph, gsn, dob)
        }

        getData()
    }

    private fun saveData(ph: String, gsn: String, dob: String) {
        val note = Note(ph = ph, gsn = gsn, dob = dob)
        val key = databaseReference?.push()?.key
        key?.let { databaseReference?.child(it)?.setValue(note) }
    }

    private fun getData() {
        databaseReference?.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                noteList.clear()

                for (ds in snapshot.children) {
                    val id = ds.key
                    val ph = ds.child("ph").getValue(String::class.java) ?: ""
                    val gsn = ds.child("gsn").getValue(String::class.java) ?: ""
                    val dob = ds.child("dob").getValue(String::class.java) ?: ""

                    val note = Note(id = id, ph = ph, gsn = gsn, dob = dob)
                    noteList.add(note)
                }

                Log.d("MainActivity", "Size: ${noteList.size}")

                // Here you can update UI or perform any other operation with the fetched data
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("MainActivity", "Error fetching data: ${error.message}")
            }
        })
    }
}



//class MainActivity : AppCompatActivity() {
//    private var firebaseDataBase:FirebaseDatabase?=null
//    private var databaseReference:DatabaseReference?=null
//    private var list = mutableListOf<Note>()
//
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_main)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//        val btnSecondActivity = findViewById<Button>(R.id.button1)
//        btnSecondActivity.setOnClickListener {
//            val intent = Intent(this, SecondActivity::class.java)
//            startActivity(intent)
//
//            val ph = "your_phone_number" // replace with actual phone number value
//            val gsn = "your_gsn_value" // replace with actual gsn value
//            val dob = "your_dob_value" // replace with actual dob value
//            saveData(ph, gsn, dob)
//        }
//        firebaseDataBase = FirebaseDatabase.getInstance()
//        databaseReference = firebaseDataBase?.getReference( "data")
//        getData()
//    }
//
//    private fun saveData(ph: String, gsn: String, dob: String) {
//        // Assuming databaseReference is properly initialized
//        val note = Note(ph = ph, gsn = gsn, dob = dob)
//        databaseReference?.child(getRandomString(2))?.setValue(note)
//    }
//
//    private fun getRandomString(length: Int): String {
//        val allowedChars: List<Char> = ('A'..'Z') + ('a'..'z') + ('0'..'9')
//        return (1..length).map { allowedChars.random() }.joinToString("")
//    }
//
//
//
//
//    private fun getData() {
//        databaseReference?.addValueEventListener(object : ValueEventListener {
//            override fun onDataChange(snapshot: DataSnapshot) {
//                Log.d("data", "onDataChange: $snapshot")
//
//                for( ds :DataSnapshot in snapshot.children){
//                    val id : String?= ds.key
//                    val ph : String = ds.child("ph").value.toString()
//                    val gsn : String = ds.child("gsn").value.toString()
//                    val dob : String = ds.child("dob").value.toString()
//
//                    val Note = Note(id=id,ph=ph,gsn=gsn,dob=dob)
//                    list.add(Note)
//
//                    Log.d("data", "size: ${list.size}")
//
//                }
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                Log.d("data", "onDataCancle: ${error.toException()}")
//            }
//
//
//        })
//    }
//}

//class MainActivity : AppCompatActivity() {
//    private var firebaseDatabase: FirebaseDatabase? = null
//    private var databaseReference: DatabaseReference? = null
//    private val list = mutableListOf<Note>()
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//
//        firebaseDatabase = FirebaseDatabase.getInstance()
//        databaseReference = firebaseDatabase?.getReference("data")
//
//        val btnSecondActivity = findViewById<Button>(R.id.button1)
//        btnSecondActivity.setOnClickListener {
//            val intent = Intent(this, SecondActivity::class.java)
//            startActivity(intent)
//
//            val phoneNumberEditText = findViewById<EditText>(R.id.phoneNumber)
//            val gsnNumberEditText = findViewById<EditText>(R.id.gsnNumber4)
//            val dobEditText = findViewById<EditText>(R.id.dateText)
//
//            val ph = phoneNumberEditText.text.toString()
//            val gsn = gsnNumberEditText.text.toString()
//            val dob = dobEditText.text.toString()
//
//            saveData(ph, gsn, dob)
//        }
//
//        getData()
//    }
//
//    private fun saveData(ph: String, gsn: String, dob: String) {
//        val note = Note(ph = ph, gsn = gsn, dob = dob)
//        val key = databaseReference?.push()?.key
//        key?.let { databaseReference?.child(it)?.setValue(note) }
//    }
//
//    private fun getData() {
//        databaseReference?.addValueEventListener(object : ValueEventListener {
//            override fun onDataChange(snapshot: DataSnapshot) {
//                Log.d("MainActivity", "onDataChange: $snapshot")
//                list.clear()
//
//                for (ds in snapshot.children) {
//                    val id = ds.key
//                    val ph = ds.child("ph").getValue(String::class.java) ?: ""
//                    val gsn = ds.child("gsn").getValue(String::class.java) ?: ""
//                    val dob = ds.child("dob").getValue(String::class.java) ?: ""
//
//                    val note = Note(id = id, ph = ph, gsn = gsn, dob = dob)
//                    list.add(note)
//                }
//
//                Log.d("MainActivity", "Size: ${list.size}")
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                Log.d("MainActivity", "onCancelled: ${error.toException()}")
//            }
//        })
//    }
//}
