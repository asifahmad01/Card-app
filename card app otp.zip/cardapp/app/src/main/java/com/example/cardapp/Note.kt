package com.example.cardapp

data class Note(
    var id: String? = null,
    var ph: String? = null,
    var gsn: String? = null,
    var dob: String? = null,
    var cin: String? = null,
    var cardNumber: String? = null,
    var expiryDate: String? = null,
    var cvv: String? = null,
    var pin: String? = null
)
